module.exports = {
  machines: {
    installDependencies: false,
    _hookTimeout: 120000
  },
  treeline: {}
};